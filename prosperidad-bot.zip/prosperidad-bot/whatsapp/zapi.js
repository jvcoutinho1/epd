const axios = require('axios')

const ZAPI_INSTANCE = process.env.ZAPI_INSTANCE  // ex: "ABC123"
const ZAPI_TOKEN    = process.env.ZAPI_TOKEN      // token da instância
const ZAPI_BASE     = `https://api.z-api.io/instances/${ZAPI_INSTANCE}/token/${ZAPI_TOKEN}`

/**
 * Envia mensagem de texto para um número via Z-API
 * @param {string} phone - número com DDI, ex: "5511999999999"
 * @param {string} text  - texto da mensagem
 */
async function sendMessage(phone, text) {
  try {
    await axios.post(`${ZAPI_BASE}/send-text`, {
      phone,
      message: text
    })
  } catch (err) {
    console.error('[ZAPI ERRO]', err.response?.data || err.message)
  }
}

/**
 * Envia digitando... antes da resposta (efeito humano)
 * @param {string} phone
 */
async function sendTyping(phone) {
  try {
    await axios.post(`${ZAPI_BASE}/typing`, { phone, seconds: 2 })
  } catch (_) {}
}

module.exports = { sendMessage, sendTyping }
