const fs   = require('fs')
const path = require('path')

const DB_PATH = path.join(__dirname, 'conversations.json')

// Garante que o arquivo existe
if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({}))
}

function load() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'))
}

function save(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2))
}

/**
 * Retorna o histórico de mensagens de um contato
 * Máximo de 20 mensagens para não estourar o contexto do Claude
 */
function getHistory(phone) {
  const db = load()
  return (db[phone]?.messages || []).slice(-20)
}

/**
 * Retorna o perfil do contato (agente atual, tipo de usuário, país detectado)
 */
function getProfile(phone) {
  const db = load()
  return db[phone] || { agent: null, type: 'lead', country: null, messages: [] }
}

/**
 * Salva uma mensagem no histórico
 */
function addMessage(phone, role, content) {
  const db = load()
  if (!db[phone]) {
    db[phone] = { agent: null, type: 'lead', country: null, messages: [] }
  }
  db[phone].messages.push({ role, content, ts: new Date().toISOString() })
  // Mantém só as últimas 50 mensagens por contato
  if (db[phone].messages.length > 50) {
    db[phone].messages = db[phone].messages.slice(-50)
  }
  save(db)
}

/**
 * Atualiza o perfil do contato
 */
function updateProfile(phone, updates) {
  const db = load()
  if (!db[phone]) {
    db[phone] = { agent: null, type: 'lead', country: null, messages: [] }
  }
  Object.assign(db[phone], updates)
  save(db)
}

/**
 * Define o agente atual do contato
 * @param {string} phone
 * @param {'sdr'|'suporte'} agent
 */
function setAgent(phone, agent) {
  updateProfile(phone, { agent })
}

module.exports = { getHistory, getProfile, addMessage, updateProfile, setAgent }
