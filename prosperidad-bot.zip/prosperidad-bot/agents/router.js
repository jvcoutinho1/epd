const Anthropic = require('@anthropic-ai/sdk')
const { SDR_SYSTEM_PROMPT }     = require('./sdr')
const { SUPORTE_SYSTEM_PROMPT } = require('./suporte')
const db = require('../db/conversations')
const { sendMessage } = require('../whatsapp/zapi')

const claude = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

// Número do dono da empresa para escalada humana
const DONO_PHONE = process.env.DONO_PHONE || '5511999999999'

/**
 * Decide qual agente responde e chama o Claude
 * @param {string} phone   - número do contato
 * @param {string} message - mensagem recebida
 * @returns {string|null}  - resposta para enviar ou null
 */
async function routeMessage(phone, message) {
  const profile = db.getProfile(phone)
  const history = db.getHistory(phone)

  // ── Decide o agente inicial ────────────────────────────────────────────
  // Se o contato nunca interagiu antes → SDR
  // Se já está marcado como aluno → Suporte
  // Se já tem agente definido → mantém
  let currentAgent = profile.agent
  if (!currentAgent) {
    currentAgent = profile.type === 'aluno' ? 'suporte' : 'sdr'
    db.setAgent(phone, currentAgent)
  }

  // ── Chama o Claude com o agente correto ────────────────────────────────
  const systemPrompt = currentAgent === 'sdr' ? SDR_SYSTEM_PROMPT : SUPORTE_SYSTEM_PROMPT

  // Monta histórico no formato Messages API
  const messages = [
    ...history.map(m => ({ role: m.role, content: m.content })),
    { role: 'user', content: message }
  ]

  let responseText = ''
  try {
    const response = await claude.messages.create({
      model:      'claude-sonnet-4-5',   // Sonnet = melhor custo-benefício para SDR/Suporte
      max_tokens: 600,
      system:     systemPrompt,
      messages
    })
    responseText = response.content[0].text
  } catch (err) {
    console.error('[CLAUDE ERRO]', err.message)
    return 'Hola! Estamos con un pequeño inconveniente tecnico. Vuelvo contigo en un momento. Que Dios te bendiga!'
  }

  // ── Salva no histórico ─────────────────────────────────────────────────
  db.addMessage(phone, 'user',      message)
  db.addMessage(phone, 'assistant', responseText)

  // ── Detecta tags de sistema e age sobre elas ───────────────────────────
  let finalText = responseText

  // Detecta país
  const paisMatch = responseText.match(/\[PAIS:(\w+)\]/i)
  if (paisMatch) {
    db.updateProfile(phone, { country: paisMatch[1] })
    finalText = finalText.replace(/\[PAIS:\w+\]/gi, '')
  }

  // Transferência para outro agente
  const transferMatch = responseText.match(/\[TRANSFER:(\w+)\]/i)
  if (transferMatch) {
    const novoAgente = transferMatch[1].toLowerCase() // 'sdr' ou 'suporte'
    db.setAgent(phone, novoAgente)
    finalText = finalText.replace(/\[TRANSFER:\w+\]/gi, '')
    console.log(`[TRANSFER] ${phone} → agente: ${novoAgente}`)

    // Chama imediatamente o novo agente com a mesma mensagem
    // para que a resposta já venha do agente correto
    const novoPrompt = novoAgente === 'sdr' ? SDR_SYSTEM_PROMPT : SUPORTE_SYSTEM_PROMPT
    try {
      const r2 = await claude.messages.create({
        model:      'claude-sonnet-4-5',
        max_tokens: 600,
        system:     novoPrompt,
        messages:   [{ role: 'user', content: message }]
      })
      const novaResposta = r2.content[0].text.replace(/\[TRANSFER:\w+\]/gi, '').replace(/\[ESCALAR:\w+\]/gi, '').replace(/\[PAIS:\w+\]/gi, '').trim()
      db.addMessage(phone, 'assistant', novaResposta)

      // Envia primeiro o texto de handoff, depois a resposta do novo agente
      await sendMessage(phone, finalText.trim())
      return novaResposta
    } catch (_) {}
  }

  // Escalada para humano
  const escalarMatch = responseText.match(/\[ESCALAR:(\w+)\]/i)
  if (escalarMatch) {
    finalText = finalText.replace(/\[ESCALAR:\w+\]/gi, '').trim()
    // Notifica o dono no WhatsApp
    const alerta = `🚨 *ESCALADA — Prosperidad Bot*\n\nContato: +${phone}\nMotivo: O agente detectou uma situação que precisa de atenção humana.\n\nÚltima mensagem do lead:\n"${message}"`
    await sendMessage(DONO_PHONE, alerta)
    console.log(`[ESCALAR] ${phone} → notificado dono`)
  }

  return finalText.trim()
}

module.exports = { routeMessage }
